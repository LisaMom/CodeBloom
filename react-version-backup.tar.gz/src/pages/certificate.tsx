import CourseCertificate from "../components/certificates/CourseCertificate";
import QuizCertificate from "../components/certificates/QuizCertificate";

export default function CertificatePreview() {
  return (
    <main className="space-y-12 bg-slate-50 p-6">
      <section>
        <h2 className="mb-4 text-xl font-bold text-slate-900">
          Course Completion
        </h2>

        <CourseCertificate
          learnerName="Mom Lisa"
          courseName="Web Development Roadmap"
          completionDate="October 19, 2026"
          certificateId="CB-COURSE-0001"
        />
      </section>

      <section>
        <h2 className="mb-4 text-xl font-bold text-slate-900">
          Final Quiz Achievement
        </h2>

        <QuizCertificate
          learnerName="Mom Lisa"
          courseName="Java Programming"
          score={85}
          assessmentDate="October 19, 2026"
          certificateId="CB-QUIZ-0001"
        />
      </section>
    </main>
  );
}