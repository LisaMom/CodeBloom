
import CertificateFrame from "./CertificateFrame";

type CourseCertificateProps = {
  learnerName: string;
  courseName: string;
  completionDate: string;
  certificateId: string;
};

export default function CourseCertificate({
  learnerName,
  courseName,
  completionDate,
  certificateId,
}: CourseCertificateProps) {
  return (
    <CertificateFrame>
      <p className="mb-2 text-sm font-bold tracking-[0.25em] text-emerald-700 uppercase">
        CodeBloom
      </p>

      <p className="mb-2 text-xs tracking-widest text-slate-500 uppercase">
        Coding Education Platform
      </p>

      <h1 className="text-2xl font-extrabold tracking-wide text-slate-900 sm:text-4xl">
        Certificate of Completion
      </h1>

      <p className="mt-4 text-sm text-slate-500 sm:text-base">
        This certificate is proudly presented to
      </p>

      <h2 className="mt-3 border-b-2 border-emerald-500 px-4 pb-2 font-serif text-2xl font-bold text-emerald-700 sm:text-4xl">
        {learnerName}
      </h2>

      <p className="mt-5 text-sm text-slate-600 sm:text-lg">
        For successfully completing the learning path
      </p>

      <h3 className="mt-2 text-xl font-bold text-indigo-600 sm:text-2xl">
        {courseName}
      </h3>

      <p className="mt-4 max-w-xl text-sm leading-6 text-slate-500">
        In recognition of your dedication to learning and
        developing your programming skills.
      </p>

      <div className="mt-6 flex w-full flex-wrap justify-center gap-6 text-xs text-slate-600 sm:text-sm">
        <p>
          Completed: <strong>{completionDate}</strong>
        </p>
        <p>
          Certificate ID: <strong>{certificateId}</strong>
        </p>
      </div>

      <div className="mt-8 flex w-full items-end justify-between gap-6 text-xs sm:text-sm">
        <div className="w-1/3 border-t border-slate-400 pt-2">
          <p className="font-semibold text-slate-800">
            CodeBloom Team
          </p>
          <p className="text-slate-500">Authorized signature</p>
        </div>

        <div className="flex size-16 shrink-0 items-center justify-center rounded-full border-4 border-emerald-600 text-xs font-extrabold text-emerald-700 sm:size-20">
          CB
        </div>

        <div className="w-1/3 border-t border-slate-400 pt-2">
          <p className="font-semibold text-slate-800">
            CodeBloom
          </p>
          <p className="text-slate-500">Learning Platform</p>
        </div>
      </div>
    </CertificateFrame>
  );
}
