
export default function CertificateActions() {
  return (
    <div className="my-6 flex justify-center gap-3 print:hidden">
      <button
        type="button"
        onClick={() => window.print()}
        className="rounded-lg bg-emerald-600 px-5 py-2.5 font-medium text-white transition hover:bg-emerald-700"
      >
        Print / Save as PDF
      </button>
    </div>
  );
}
