
import CertificateFrame from "./CertificateFrame";

type QuizCertificateProps = {
  learnerName: string;
  courseName: string;
  score: number;
  assessmentDate: string;
  certificateId: string;
};

export default function QuizCertificate({
  learnerName,
  courseName,
  score,
  assessmentDate,
  certificateId,
}: QuizCertificateProps) {
  return (
    <CertificateFrame>
      <p className="mb-2 text-sm font-bold tracking-[0.25em] text-indigo-700 uppercase">
        CodeBloom
      </p>

      <h1 className="text-2xl font-extrabold text-slate-900 sm:text-4xl">
        Certificate of Achievement
      </h1>

      <p className="mt-4 text-sm text-slate-500">
        Awarded to
      </p>

      <h2 className="mt-3 border-b-2 border-indigo-500 px-4 pb-2 font-serif text-2xl font-bold text-indigo-700 sm:text-4xl">
        {learnerName}
      </h2>

      <p className="mt-5 text-sm text-slate-600 sm:text-lg">
        For passing the final assessment in
      </p>

      <h3 className="mt-2 text-xl font-bold text-emerald-700 sm:text-2xl">
        {courseName}
      </h3>

      <div className="mt-5 rounded-xl border border-indigo-100 bg-indigo-50 px-8 py-4">
        <p className="text-sm text-slate-500">Final Score</p>

        <p className="mt-1 text-3xl font-extrabold text-indigo-700">
          {score}%
        </p>

        <p className="mt-1 text-xs font-bold tracking-wider text-emerald-700">
          PASSED
        </p>
      </div>

      <p className="mt-4 text-sm text-slate-500">
        Assessment date: {assessmentDate}
      </p>

      <div className="mt-6 border-t border-slate-300 pt-3 text-xs text-slate-500">
        Certificate ID: {certificateId}
      </div>

      <p className="mt-4 text-xs font-semibold text-slate-600">
        CODEBLOOM · CODING EDUCATION PLATFORM
      </p>
    </CertificateFrame>
  );
}
