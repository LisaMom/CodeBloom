
import type { ReactNode } from "react";

type CertificateFrameProps = {
  children: ReactNode;
};

export default function CertificateFrame({
  children,
}: CertificateFrameProps) {
  return (
    <div className="w-full overflow-x-auto">
      <article
        id="certificate"
        className="relative mx-auto aspect-[1.414/1] w-full min-w-[650px] max-w-[1120px] border-[10px] border-slate-200 bg-white p-5 sm:p-8 print:mx-0 print:w-[297mm] print:max-w-none print:min-w-0 print:border-[8px] print:p-8"
      >
        {/* Decorative inner border */}
        <div className="pointer-events-none absolute inset-3 border-2 border-emerald-600 sm:inset-5 sm:border-4" />

        {/* Certificate content */}
        <div className="relative flex h-full flex-col items-center justify-center px-4 py-3 text-center sm:px-8">
          {children}
        </div>
      </article>
    </div>
  );
}
